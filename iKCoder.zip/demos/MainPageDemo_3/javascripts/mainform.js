﻿window.addEventListener('load', onLoad);

function onLoad() {
    buildHeader(true);
    buildFooter();
}